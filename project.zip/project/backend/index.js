const { urlencoded } = require('express');
const express = require('express');
const app = express();
var cors = require('cors');
const mongoose = require('mongoose');
const { json } = require('stream/consumers');
const bodyparser = require('body-parser');
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({
    extended:true,
}));
// parse requests of content-type - application/json
app.use(bodyparser.json())

mongoose.Promise = global.Promise;

mongoose.connect("mongodb://localhost:27017/Product", {
    useNewUrlParser: true
}).then(() => {
    console.log("Successfully connected to the database");
}).catch(err => {
    console.log('Could not connect to the database. Exiting now...', err);
    process.exit();
});

const schema = new mongoose.Schema({
    productcategory :{
        type: String,
    }
    ,productName : {
        type:String
    },
    price:{
        type:Number
    }
});
const Product = mongoose.model('Product',schema);

app.listen(4300, ()=>{
    console.log("Server is running on 4300 port");
});


app.get('/product', cors(),(req,res)=>{
    Product.find({})
    .then((posts) =>{
        res.json(posts);
        console.log(posts);
    })
    .catch(err =>{
        console.log("Error");
    });
});

app.get('/productByCategory',(req,res)=>{
    Product.find({productcategory:req.body.productcategory})
    .then((posts) =>{
        res.json(posts);
    })
    .catch(err =>{
        console.log("Error");
    });
});

app.post('/saveData', (req,res)=>{
    const product = new Product({
        productcategory: req.body.productcategory,
        productName: req.body.productName,
        price:req.body.price,
    });
    product.save()
    .then((result) => {
		res.send(result);
	}).catch((err) =>{
		console.log(err);
    });
});